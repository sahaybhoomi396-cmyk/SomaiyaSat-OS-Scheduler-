class SatelliteTask:
    def __init__(self, process_id, task_name, arrival_time, burst_time):
        self.process_id = process_id
        self.task_name = task_name
        self.arrival_time = arrival_time
        self.burst_time = burst_time

        self.remaining_time = burst_time
        self.start_time = None
        self.completion_time = None
        self.waiting_time = 0
        self.turnaround_time = 0
        self.state = "NEW"

    def reset(self):
        self.remaining_time = self.burst_time
        self.start_time = None
        self.completion_time = None
        self.waiting_time = 0
        self.turnaround_time = 0
        self.state = "NEW"

    def calculate_metrics(self):
        if self.completion_time is not None:
            self.turnaround_time = self.completion_time - self.arrival_time
            self.waiting_time = self.turnaround_time - self.burst_time

    def __repr__(self):
        return (
            f"{self.process_id} - {self.task_name} "
            f"(AT={self.arrival_time}, BT={self.burst_time})"
        )
