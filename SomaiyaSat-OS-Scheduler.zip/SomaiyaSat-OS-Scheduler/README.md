# SomaiyaSat OS Scheduler

Python simulator that schedules the radio payload tasks of **SomaiyaSat**, a PocketQube satellite
(M17, Codec2, SSTV, TT&C / housekeeping), inside limited ground-station communication windows using
**Shortest Job First (SJF)** and **Round Robin (RR)**.

Part of AI Use Case **KJS-SRS-01** — *SomaiyaSat & SomaiyaPod: A PocketQube Mission featuring Autonomous
AI-Based Inter-Satellite Data Routing and Advanced Multi-Mode Amateur Radio Payloads*
(K J Somaiya, collaborating organisation: ReOrbit, Finland).

**Author:** Bhoomi Sahay · Roll No. 16010424107 · Lab Batch B2

## What it does
- Models each payload transmission as an OS process (arrival time, burst time, state, remaining time)
- Basic SJF and Round Robin (no window limit) as reference runs
- **Windowed SJF / Windowed Round Robin** across one or more communication passes
- Partial transmission and carry-over of unfinished tasks to the next pass
- Metrics: waiting time, turnaround time, context switches, window utilisation, completed / partial / pending tasks
- Three predefined scenarios and a side-by-side SJF vs RR comparison
- Result export to text files

Standard library only. No AI/ML, databases or internet access are needed. The simulator is the deterministic
baseline (and rule-based fallback) for the AI-based router described in the use case.

## Run
```bash
python main.py
```
Python 3.8+.

## Scenarios
| Scenario | Task set | Passes | Quantum |
|---|---|---|---|
| 1 – Normal | baseline (SSTV = 8 s) | 10 s + 10 s | 2 s |
| 2 – Short window | baseline (SSTV = 8 s) | 6 s + 6 s | 2 s |
| 3 – Heavy SSTV | SSTV = 15 s, Codec2 = 3 s, M17 = 4 s | 10 s + 10 s | 2 s |

Menu option **4** runs both algorithms on the chosen scenario.

## Results (windowed, q = 2 s)
| Scenario | Algorithm | Avg wait (s) | Avg turnaround (s) | Ctx switches | Completed | Partial | Pending |
|---|---|---|---|---|---|---|---|
| 1 | SJF | 1.75 | 5.00 | 4 | 4 | 1 | 0 |
| 1 | Round Robin | 5.75 | 9.00 | 10 | 4 | 1 | 0 |
| 2 | SJF | 0.67 | 3.33 | 3 | 3 | 1 | 1 |
| 2 | Round Robin | 2.00 | 5.00 | 5 | 2 | 2 | 1 |
| 3 | SJF | 1.25 | 4.00 | 4 | 4 | 1 | 0 |
| 3 | Round Robin | 5.00 | 7.75 | 8 | 4 | 1 | 0 |

Averages are over completed tasks only; read them together with the completed/partial/pending counts.

**Key finding:** neither policy is criticality-aware. In Scenario 2, Round Robin leaves Housekeeping
untransmitted, and SJF starves the long SSTV job. This motivates priority-aware and AI-based routing.

## Repository layout
```
main.py          menu-driven simulator
process.py       SatelliteTask class
scheduler.py     SJF, RR, windowed SJF, windowed RR
simulation.py    metrics, Gantt, utilisation, export
scenarios/       JSON task sets
results/         saved run outputs
docs/            use-case document and project write-up (PDF)
```

## Future work
Priority classes with reserved airtime for TT&C/housekeeping, aging, link-quality and power-aware bursts,
pass times from STK/GMAT, a lightweight learned policy compared against these baselines, and
hardware-in-the-loop testing.
