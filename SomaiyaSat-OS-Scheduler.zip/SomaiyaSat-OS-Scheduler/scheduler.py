from collections import deque


def _reset(tasks):
    for task in tasks:
        task.reset()


def sjf(tasks):
    """Non-preemptive SJF with arrival times, without communication-window limits."""
    _reset(tasks)
    items = [{"task": t, "completed": False} for t in tasks]
    time = 0
    done = 0
    order, gantt = [], []

    while done < len(tasks):
        available = [x for x in items if not x["completed"] and x["task"].arrival_time <= time]
        if not available:
            time = min(x["task"].arrival_time for x in items if not x["completed"])
            continue
        selected = min(available, key=lambda x: (x["task"].burst_time, x["task"].arrival_time, x["task"].process_id))
        task = selected["task"]
        task.state = "RUNNING"
        if task.start_time is None:
            task.start_time = time
        start = time
        time += task.burst_time
        task.remaining_time = 0
        task.completion_time = time
        task.state = "TERMINATED"
        task.calculate_metrics()
        selected["completed"] = True
        done += 1
        order.append(task.process_id)
        gantt.append((task.process_id, start, time))
    return order, gantt


def round_robin(tasks, time_quantum):
    """Round Robin with arrival times, without communication-window limits."""
    if time_quantum <= 0:
        raise ValueError("Time quantum must be greater than zero.")
    _reset(tasks)
    items = [{"task": t, "remaining": t.burst_time, "added": False} for t in tasks]
    q = deque()
    time = 0
    done = 0
    order, gantt = [], []
    switches = 0
    last = None

    while done < len(tasks):
        for x in items:
            if not x["added"] and x["task"].arrival_time <= time:
                q.append(x); x["added"] = True; x["task"].state = "READY"

        if not q:
            time = min(x["task"].arrival_time for x in items if not x["added"])
            continue

        cur = q.popleft()
        task = cur["task"]
        if last is not None and last != task.process_id:
            switches += 1
        last = task.process_id

        task.state = "RUNNING"
        if task.start_time is None:
            task.start_time = time
        start = time
        used = min(time_quantum, cur["remaining"])
        time += used
        cur["remaining"] -= used
        task.remaining_time = cur["remaining"]
        gantt.append((task.process_id, start, time))
        order.append(task.process_id)

        for x in items:
            if not x["added"] and x["task"].arrival_time <= time:
                q.append(x); x["added"] = True; x["task"].state = "READY"

        if cur["remaining"] == 0:
            task.completion_time = time
            task.state = "TERMINATED"
            task.calculate_metrics()
            done += 1
        else:
            task.state = "READY"
            q.append(cur)

    return order, gantt, switches


def windowed_sjf(tasks, window_durations):
    """
    SJF across one or more communication passes.
    A task may be partially transmitted when a pass closes.
    Remaining time is carried to the next pass.
    """
    _reset(tasks)
    for t in tasks:
        t.remaining_time = t.burst_time

    time = 0
    order, gantt = [], []
    pass_results = []
    completed = 0
    context_switches = 0
    last_pid = None

    for pass_no, duration in enumerate(window_durations, start=1):
        pass_start = time
        pass_end = pass_start + duration
        pass_used = 0
        pass_completed = []
        pass_partial = []

        while time < pass_end and completed < len(tasks):
            available = [
                t for t in tasks
                if t.remaining_time > 0 and t.arrival_time <= time
            ]

            if not available:
                future = [t.arrival_time for t in tasks if t.remaining_time > 0 and t.arrival_time > time]
                if not future or min(future) >= pass_end:
                    time = pass_end
                    break
                time = min(future)
                continue

            task = min(
                available,
                key=lambda t: (t.remaining_time, t.arrival_time, t.process_id)
            )
            if last_pid is not None and last_pid != task.process_id:
                context_switches += 1
            last_pid = task.process_id

            task.state = "RUNNING"
            if task.start_time is None:
                task.start_time = time

            available_window = pass_end - time
            used = min(task.remaining_time, available_window)
            start = time
            time += used
            task.remaining_time -= used
            pass_used += used
            gantt.append((task.process_id, start, time))
            order.append(task.process_id)

            if task.remaining_time == 0:
                task.completion_time = time
                task.state = "TERMINATED"
                task.calculate_metrics()
                completed += 1
                pass_completed.append(task.process_id)
            else:
                task.state = "BLOCKED"
                pass_partial.append(task.process_id)

            if time >= pass_end:
                break

        time = pass_end
        for t in tasks:
            if t.remaining_time > 0 and t.state == "RUNNING":
                t.state = "BLOCKED"

        pending = [t.process_id for t in tasks if t.remaining_time > 0]
        pass_results.append({
            "pass": pass_no,
            "start": pass_start,
            "end": pass_end,
            "duration": duration,
            "used": pass_used,
            "completed": pass_completed,
            "partial": list(dict.fromkeys(pass_partial)),
            "pending": pending,
        })

    # Anything not completed after the provided passes remains pending.
    return {
        "algorithm": "SJF",
        "execution_order": order,
        "gantt": gantt,
        "context_switches": context_switches,
        "pass_results": pass_results,
        "tasks": tasks,
    }


def windowed_round_robin(tasks, time_quantum, window_durations):
    """
    Round Robin across communication passes.
    A task may be partially transmitted at pass close and resumes later.
    """
    if time_quantum <= 0:
        raise ValueError("Time quantum must be greater than zero.")

    _reset(tasks)
    for t in tasks:
        t.remaining_time = t.burst_time

    items = [{"task": t, "added": False} for t in tasks]
    q = deque()
    time = 0
    completed = 0
    order, gantt = [], []
    pass_results = []
    context_switches = 0
    last_pid = None

    for pass_no, duration in enumerate(window_durations, start=1):
        pass_start = time
        pass_end = pass_start + duration
        pass_used = 0
        pass_completed = []
        pass_partial = []

        # Rebuild queue from tasks that are already available and unfinished.
        q.clear()
        for x in items:
            x["added"] = False
        for x in items:
            if x["task"].remaining_time > 0 and x["task"].arrival_time <= time:
                q.append(x); x["added"] = True; x["task"].state = "READY"

        while time < pass_end and completed < len(tasks):
            # Add newly arrived tasks.
            for x in items:
                if (
                    not x["added"]
                    and x["task"].remaining_time > 0
                    and x["task"].arrival_time <= time
                ):
                    q.append(x); x["added"] = True; x["task"].state = "READY"

            if not q:
                future = [
                    x["task"].arrival_time for x in items
                    if not x["added"] and x["task"].remaining_time > 0
                ]
                if not future or min(future) >= pass_end:
                    time = pass_end
                    break
                time = min(future)
                continue

            cur = q.popleft()
            task = cur["task"]

            if last_pid is not None and last_pid != task.process_id:
                context_switches += 1
            last_pid = task.process_id

            task.state = "RUNNING"
            if task.start_time is None:
                task.start_time = time

            start = time
            used = min(time_quantum, task.remaining_time, pass_end - time)
            time += used
            task.remaining_time -= used
            pass_used += used
            gantt.append((task.process_id, start, time))
            order.append(task.process_id)

            for x in items:
                if (
                    not x["added"]
                    and x["task"].remaining_time > 0
                    and x["task"].arrival_time <= time
                ):
                    q.append(x); x["added"] = True; x["task"].state = "READY"

            if task.remaining_time == 0:
                task.completion_time = time
                task.state = "TERMINATED"
                task.calculate_metrics()
                completed += 1
                pass_completed.append(task.process_id)
            else:
                if time >= pass_end:
                    task.state = "BLOCKED"
                    pass_partial.append(task.process_id)
                else:
                    task.state = "READY"
                    q.append(cur)

        time = pass_end
        pending = [t.process_id for t in tasks if t.remaining_time > 0]
        pass_results.append({
            "pass": pass_no,
            "start": pass_start,
            "end": pass_end,
            "duration": duration,
            "used": pass_used,
            "completed": pass_completed,
            "partial": list(dict.fromkeys(pass_partial)),
            "pending": pending,
        })

    return {
        "algorithm": "Round Robin",
        "time_quantum": time_quantum,
        "execution_order": order,
        "gantt": gantt,
        "context_switches": context_switches,
        "pass_results": pass_results,
        "tasks": tasks,
    }
