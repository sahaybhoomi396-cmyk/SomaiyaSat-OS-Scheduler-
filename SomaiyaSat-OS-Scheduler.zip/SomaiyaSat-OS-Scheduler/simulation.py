def metrics(tasks):
    completed = [t for t in tasks if t.completion_time is not None]
    avg_waiting = sum(t.waiting_time for t in completed) / len(completed) if completed else 0
    avg_turnaround = sum(t.turnaround_time for t in completed) / len(completed) if completed else 0
    return {
        "average_waiting_time": avg_waiting,
        "average_turnaround_time": avg_turnaround,
        "completed_tasks": len(completed),
        "partial_tasks": sum(1 for t in tasks if t.remaining_time > 0 and t.remaining_time < t.burst_time),
        "pending_tasks": sum(1 for t in tasks if t.remaining_time == t.burst_time),
    }


def format_gantt(gantt):
    return " -> ".join(f"[{s}-{e}: {pid}]" for pid, s, e in gantt) if gantt else "No execution recorded."


def communication_utilization(result):
    total_window = sum(p["duration"] for p in result["pass_results"])
    used = sum(p["used"] for p in result["pass_results"])
    return (used / total_window * 100) if total_window else 0


def save_result(result, filename):
    m = metrics(result["tasks"])
    with open(filename, "w", encoding="utf-8") as f:
        f.write("=" * 75 + "\n")
        f.write("SOMAIYASAT OS COMMUNICATION SCHEDULING RESULT\n")
        f.write("=" * 75 + "\n")
        f.write(f"Algorithm: {result['algorithm']}\n")
        if "time_quantum" in result:
            f.write(f"Time Quantum: {result['time_quantum']} sec\n")
        f.write(f"Execution Order: {' -> '.join(result['execution_order'])}\n")
        f.write(f"Gantt Chart: {format_gantt(result['gantt'])}\n")
        f.write(f"Context Switches: {result['context_switches']}\n")
        f.write(f"Communication Utilization: {communication_utilization(result):.2f}%\n\n")

        f.write("PASS SUMMARY\n")
        for p in result["pass_results"]:
            f.write(
                f"Pass {p['pass']} ({p['start']}-{p['end']} sec): "
                f"Used={p['used']} sec | "
                f"Completed={p['completed']} | "
                f"Partial={p['partial']} | "
                f"Pending={p['pending']}\n"
            )

        f.write("\nPROCESS RESULTS\n")
        f.write("-" * 75 + "\n")
        f.write(f"{'PID':<8}{'Task':<20}{'AT':<8}{'BT':<8}{'CT':<8}{'TAT':<8}{'WT':<8}{'Remaining':<10}\n")
        f.write("-" * 75 + "\n")
        for t in result["tasks"]:
            f.write(
                f"{t.process_id:<8}{t.task_name:<20}{t.arrival_time:<8}"
                f"{t.burst_time:<8}{str(t.completion_time):<8}"
                f"{str(t.turnaround_time):<8}{str(t.waiting_time):<8}"
                f"{t.remaining_time:<10}\n"
            )

        f.write("\nMETRICS\n")
        f.write(f"Average Waiting Time: {m['average_waiting_time']:.2f}\n")
        f.write(f"Average Turnaround Time: {m['average_turnaround_time']:.2f}\n")
        f.write(f"Completed Tasks: {m['completed_tasks']}\n")
        f.write(f"Partial Tasks: {m['partial_tasks']}\n")
        f.write(f"Pending Tasks: {m['pending_tasks']}\n")
