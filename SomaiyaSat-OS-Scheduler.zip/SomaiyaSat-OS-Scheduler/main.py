import json
import os

from process import SatelliteTask
from scheduler import sjf, round_robin, windowed_sjf, windowed_round_robin
from simulation import metrics, format_gantt, communication_utilization, save_result

SCENARIO_FILE = os.path.join("scenarios", "satellite_tasks.json")
SCENARIO_DIR = "scenarios"
RESULTS_DIR = "results"


def load_tasks(filename=SCENARIO_FILE):
    with open(filename, "r", encoding="utf-8") as f:
        data = json.load(f)
    return [SatelliteTask(x["process_id"], x["task_name"], x["arrival_time"], x["burst_time"]) for x in data]


def print_tasks(tasks):
    print("\nINPUT TASKS")
    print("-" * 65)
    print(f"{'PID':<8}{'Task':<20}{'Arrival':<12}{'Burst':<10}")
    print("-" * 65)
    for t in tasks:
        print(f"{t.process_id:<8}{t.task_name:<20}{t.arrival_time:<12}{t.burst_time:<10}")


def print_result(result):
    m = metrics(result["tasks"])
    print("\n" + "=" * 75)
    print("SIMULATION RESULT")
    print("=" * 75)
    print(f"Algorithm             : {result['algorithm']}")
    if "time_quantum" in result:
        print(f"Time Quantum          : {result['time_quantum']} sec")
    print(f"Execution Order       : {' -> '.join(result['execution_order'])}")
    print(f"Gantt Chart           : {format_gantt(result['gantt'])}")
    print(f"Context Switches      : {result['context_switches']}")
    print(f"Average Waiting Time  : {m['average_waiting_time']:.2f}")
    print(f"Average Turnaround    : {m['average_turnaround_time']:.2f}")

    if "pass_results" in result:
        print(f"Communication Util.   : {communication_utilization(result):.2f}%")
        print("\nCOMMUNICATION PASSES")
        for p in result["pass_results"]:
            print(
                f"Pass {p['pass']} | Window {p['start']}-{p['end']} sec | "
                f"Used {p['used']} sec"
            )
            print(f"  Completed: {p['completed'] or 'None'}")
            print(f"  Partial  : {p['partial'] or 'None'}")
            print(f"  Pending  : {p['pending'] or 'None'}")

    print("\nPROCESS RESULTS")
    print("-" * 85)
    print(f"{'PID':<8}{'Task':<20}{'AT':<8}{'BT':<8}{'CT':<8}{'TAT':<8}{'WT':<8}{'Remaining':<10}")
    print("-" * 85)
    for t in result["tasks"]:
        print(
            f"{t.process_id:<8}{t.task_name:<20}{t.arrival_time:<8}"
            f"{t.burst_time:<8}{str(t.completion_time):<8}"
            f"{str(t.turnaround_time):<8}{str(t.waiting_time):<8}"
            f"{t.remaining_time:<10}"
        )
    print("=" * 75)


def run_basic_sjf():
    tasks = load_tasks()
    order, gantt = sjf(tasks)
    result = {"algorithm": "SJF", "execution_order": order, "gantt": gantt,
              "context_switches": max(0, len(gantt)-1), "tasks": tasks}
    print_result(result)


def run_basic_rr():
    q = int(input("Enter Time Quantum: "))
    tasks = load_tasks()
    order, gantt, switches = round_robin(tasks, q)
    result = {"algorithm": "Round Robin", "time_quantum": q,
              "execution_order": order, "gantt": gantt,
              "context_switches": switches, "tasks": tasks}
    print_result(result)


def run_windowed():
    print("\nCommunication window can contain multiple passes.")
    raw = input("Enter pass durations separated by commas (example: 10,10): ").strip()
    windows = [int(x.strip()) for x in raw.split(",") if x.strip()]
    if not windows or any(x <= 0 for x in windows):
        raise ValueError("Pass durations must be positive.")

    algo = input("Choose algorithm (1=SJF, 2=Round Robin): ").strip()
    if algo == "1":
        tasks = load_tasks()
        result = windowed_sjf(tasks, windows)
        filename = os.path.join(RESULTS_DIR, "windowed_sjf_result.txt")
    elif algo == "2":
        q = int(input("Enter Time Quantum: "))
        tasks = load_tasks()
        result = windowed_round_robin(tasks, q, windows)
        filename = os.path.join(RESULTS_DIR, "windowed_round_robin_result.txt")
    else:
        print("Invalid algorithm.")
        return

    print_result(result)
    save_result(result, filename)
    print(f"\nSaved: {filename}")


def run_scenarios():
    files = sorted(x for x in os.listdir(SCENARIO_DIR) if x.endswith(".json"))
    print("\nAVAILABLE SCENARIOS")
    for i, name in enumerate(files, 1):
        print(f"{i}. {name}")
    choice = int(input("Choose scenario: ")) - 1
    selected = os.path.join(SCENARIO_DIR, files[choice])

    tasks = load_tasks(selected)
    print_tasks(tasks)

    windows = [int(x.strip()) for x in input("Enter communication pass durations (example: 10,10): ").split(",") if x.strip()]
    q = int(input("Enter RR time quantum for comparison: "))

    s = windowed_sjf(load_tasks(selected), windows)
    r = windowed_round_robin(load_tasks(selected), q, windows)

    sm, rm = metrics(s["tasks"]), metrics(r["tasks"])
    print("\n" + "=" * 75)
    print("SCENARIO COMPARISON")
    print("=" * 75)
    print(f"{'Metric':<30}{'SJF':<20}{'Round Robin':<20}")
    print("-" * 75)
    print(f"{'Average Waiting Time':<30}{sm['average_waiting_time']:<20.2f}{rm['average_waiting_time']:<20.2f}")
    print(f"{'Average Turnaround Time':<30}{sm['average_turnaround_time']:<20.2f}{rm['average_turnaround_time']:<20.2f}")
    print(f"{'Context Switches':<30}{s['context_switches']:<20}{r['context_switches']:<20}")
    print(f"{'Completed Tasks':<30}{sm['completed_tasks']:<20}{rm['completed_tasks']:<20}")
    print(f"{'Partial Tasks':<30}{sm['partial_tasks']:<20}{rm['partial_tasks']:<20}")
    print(f"{'Pending Tasks':<30}{sm['pending_tasks']:<20}{rm['pending_tasks']:<20}")
    print(f"{'Window Utilization':<30}{communication_utilization(s):<20.2f}%{communication_utilization(r):<20.2f}%")
    print("=" * 75)


def main():
    os.makedirs(RESULTS_DIR, exist_ok=True)

    while True:
        print("\n╔════════════════════════════════════════════════════════╗")
        print("║       SOMAIYASAT OS SCHEDULING SIMULATOR              ║")
        print("╠════════════════════════════════════════════════════════╣")
        print("║  1. Basic SJF                                         ║")
        print("║  2. Basic Round Robin                                 ║")
        print("║  3. SJF/RR with Communication Windows                ║")
        print("║  4. Run Scenario Comparison                           ║")
        print("║  5. View Input Scenario                               ║")
        print("║  6. Exit                                               ║")
        print("╚════════════════════════════════════════════════════════╝")

        choice = input("Enter choice: ").strip()

        try:
            if choice == "1":
                run_basic_sjf()
            elif choice == "2":
                run_basic_rr()
            elif choice == "3":
                run_windowed()
            elif choice == "4":
                run_scenarios()
            elif choice == "5":
                print_tasks(load_tasks())
            elif choice == "6":
                print("Exiting SomaiyaSat OS Simulator.")
                break
            else:
                print("Invalid choice. Please enter 1-6.")
        except (ValueError, FileNotFoundError, json.JSONDecodeError, IndexError) as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    main()
